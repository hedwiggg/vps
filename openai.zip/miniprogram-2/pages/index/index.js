// 定义 TextDecoder1 类

import encoding from '../../utils/encoding'
const app = getApp();

/**
 * 十六进制字符串转中文
 * @param {String} hex 为十六进制字符串
 * @return {String} 包含中文的字符串
 */
function hexToStr(hex) {
  // 去掉字符串首尾空格
  let trimedStr = hex.trim()
  // 判断trimedStr前两个字符是否为0x，如果是则截取从第三个字符及后面所有，否则返回全部字符
  let rawStr = trimedStr.substr(0, 2).toLowerCase() === "0x" ? trimedStr.substr(2) : trimedStr
  // 得到rawStr的长度
  let len = rawStr.length
  // 如果长度不能被2整除，那么传入的十六进制值有误，返回空字符
  if (len % 2 !== 0) {
    return ""
  }
  let curCharCode // 接收每次循环得到的字符
  let resultStr = [] // 存转换后的十进制值数组
  for (let i = 0; i < len; i = i + 2) {
    curCharCode = parseInt(rawStr.substr(i, 2), 16)
    resultStr.push(curCharCode)
  }
  // encoding为空时默认为utf-8
  let bytesView = new Uint8Array(resultStr) // 8 位无符号整数值的类型化数组
  // TextEncoder和TextDecoder对字符串和字节流互转  
  // let str = new TextDecoder(encoding).decode(bytesView)因为小程序中没有TextDecoder,经查阅资料，下载https://github.com/inexorabletash/text-encoding并const encoding = require("./text-encoding-master/lib/encoding.js")引入后使用下面方式即可：
  let str = new encoding.TextDecoder("utf-8").decode(bytesView)
  return str
}

function buf2hex(arrayBuffer) {
  return Array.prototype.map.call(new Uint8Array(arrayBuffer), x => ('00' + x.toString(16)).slice(-2)).join('');
}
Page({
  data: {
    inputValue: '',
    messages: [],
    str_messages: [],
    audios: [],
    audiooo: '',
    toView: '',
    loading: false, // 控制等待动效的显示与隐藏
    myOptions: {},
    user_avatar: '',
    toLast: 'item0',
    test:'',
    all_msg:'',
    color:'#fedcbd',
    color_arr:["#fedcbd",
    "#deab8a",
    "#444693",
    "#817936",
    "#f7acbc",
    "#ef5b9c",
    "#7f7522",
    "#2b4490",
    "#feeeed",
    "#f47920",
    "#80752c",
    "#2a5caa",
    "#f05b72",
    "#905a3d",
    "#87843b",
    "#224b8f",
    "#f15b6c",
    "#8f4b2e",
    "#726930",
    "#003a6c",
    "#f8aba6",
    "#87481f",
    "#454926",
    "#102b6a",
    "#f69c9f",
    "#5f3c23",
    "#2e3a1f",
    "#426ab3",
    "#f58f98",
    "#6b473c",
    "#4d4f36",
    "#46485f",
    "#ca8687",
    "#faa755",
    "#b7ba6b",
    "#4e72b8",
    "#f391a9",
    "#fab27b",
    "#b2d235",
    "#181d4b",
    "#bd6758",
    "#f58220",
    "#5c7a29",
    "#1a2933",
    "#d71345",
    "#843900",
    "#bed742",
    "#121a2a",
    "#d64f44",
    "#905d1d",
    "#7fb80e",
    "#0c212b",
    "#d93a49",
    "#8a5d19",
    "#a3cf62",
    "#6a6da9",
    "#b3424a",
    "#8c531b",
    "#769149",
    "#585eaa",
    "#c76968",
    "#826858",
    "#6d8346",
    "#494e8f",
    "#bb505d",
    "#64492b",
    "#78a355",
    "#afb4db",
    "#987165",
    "#ae6642",
    "#abc88b",
    "#9b95c9",
    "#ac6767",
    "#56452d",
    "#74905d",
    "#6950a1",
    "#973c3f",
    "#96582a",
    "#cde6c7",
    "#6f60aa",
    "#b22c46",
    "#705628",
    "#1d953f",
    "#867892",
    "#a7324a",
    "#4a3113",
    "#77ac98",
    "#918597",
    "#aa363d",
    "#412f1f",
    "#007d65",
    "#6f6d85",
    "#ed1941",
    "#845538",
    "#84bf96",
    "#594c6d",
    "#f26522",
    "#8e7437",
    "#45b97c",
    "#694d9f",
    "#d2553d",
    "#69541b",
    "#225a1f",
    "#6f599c",
    "#b4534b",
    "#d5c59f",
    "#367459",
    "#8552a1",
    "#ef4136",
    "#cd9a5b",
    "#007947",
    "#543044",
    "#c63c26",
    "#cd9a5b",
    "#40835e",
    "#63434f",
    "#f3715c",
    "#b36d41",
    "#2b6447",
    "#7d5886",
    "#a7573b",
    "#df9464",
    "#005831",
    "#401c44",
    "#aa2116",
    "#b76f40",
    "#006c54",
    "#472d56",
    "#b64533",
    "#ad8b3d",
    "#375830",
    "#45224a",
    "#b54334",
    "#dea32c",
    "#274d3d",
    "#411445",
    "#853f04",
    "#d1923f",
    "#375830",
    "#4b2f3d",
    "#840228",
    "#c88400",
    "#27342b",
    "#402e4c",
    "#7a1723",
    "#c37e00",
    "#65c294",
    "#c77eb5",
    "#a03939",
    "#c37e00",
    "#73b9a2",
    "#ea66a6",
    "#8a2e3b",
    "#e0861a",
    "#72baa7",
    "#f173ac",
    "#8e453f",
    "#ffce7b",
    "#005344",
    "#fffffb",
    "#8f4b4a",
    "#fcaf17",
    "#122e29",
    "#fffef9",
    "#892f1b",
    "#ba8448",
    "#293047",
    "#f6f5ec",
    "#6b2c25",
    "#896a45",
    "#00ae9d",
    "#d9d6c3",
    "#733a31",
    "#76624c",
    "#508a88",
    "#d1c7b7",
    "#54211d",
    "#6d5826",
    "#70a19f",
    "#f2eada",
    "#78331e",
    "#ffc20e",
    "#50b7c1",
    "#d3d7d4",
    "#53261f",
    "#fdb933",
    "#00a6ac",
    "#999d9c",
    "#f15a22",
    "#d3c6a6",
    "#78cdd1",
    "#a1a3a6",
    "#b4533c",
    "#c7a252",
    "#008792",
    "#9d9087",
    "#8a8c8e",
    "#84331f",
    "#dec674",
    "#94d6da",
    "#f47a55",
    "#74787c",
    "#b69968",
    "#afdfe4",
    "#c1a173",
    "#f15a22",
    "#5e7c85",
    "#7c8577",
    "#f3704b",
    "#dbce8f",
    "#76becc",
    "#72777b",
    "#da765b",
    "#ffd400",
    "#90d7ec",
    "#77787b",
    "#c85d44",
    "#ffd400",
    "#009ad6",
    "#4f5555",
    "#ae5039",
    "#ffe600",
    "#145b7d",
    "#6c4c49",
    "#6a3427",
    "#f0dc70",
    "#11264f",
    "#563624",
    "#8f4b38",
    "#fcf16e",
    "#7bbfea",
    "#3e4145",
    "#8e3e1f",
    "#decb00",
    "#33a3dc",
    "#3c3645",
    "#f36c21",
    "#cbc547",
    "#228fbd",
    "#464547",
    "#b4532a",
    "#6e6b41",
    "#2468a2",
    "#130c0e",
    "#b7704f",
    "#596032",
    "#2570a1",
    "#281f1d",
    "#de773f",
    "#525f42",
    "#2585a6",
    "#2f271d",
    "#c99979",
    "#5f5d46",
    "#1b315e",
    "#1d1626"]
  },

  onLoad: function () {
    const that = this;
  },
  

  onInput: function (e) {
    this.setData({
      inputValue: e.detail.value,
    });
  },
  addMessage: function (message, position, avatar, update) {
    if(message === null || message == '') {
      return;
    }
    var mmmsg =  app.towxml(message,'markdown',{})
    
    if(update == null) {
      
      const that = this;
      const messages = that.data.messages;
      const str_messages = that.data.str_messages;
      const audios = that.data.audios;
      audios.push(encodeURI(message))
      var a = encodeURI(message)
      that.setData({
        audiooo: a
      })
      
      messages.push({
        content: mmmsg,
        position: position,
        avatar: avatar
      });
      let innerMsg = ''
      if(position === 'right') {
        innerMsg = '我：'+message
      } else {
        innerMsg = 'ChatGpt：'+message
      }
      str_messages.push({
        content:innerMsg
      })
      
      that.setData({
        messages: messages,
        str_messages : str_messages
      });
    } else {
    const that = this;
    const messages = that.data.messages;
    const str_messages = that.data.str_messages;
    
    var a = encodeURI(message)
    that.setData({
      audiooo: a
    })
    let msg = {
      content: mmmsg,
      position: position,
      avatar: avatar
    }
    messages[messages.length-1] = msg;
    let aaa = 'ChatGpt：'+message
    let cc = {
      content: aaa
    }
    str_messages[str_messages.length-1] = cc;
    that.setData({
      messages: messages,
      str_messages: str_messages
    });
    

    }
    
  },
  onConfirm: function (event) {
    this.onSend(); // 在这里手动调用按钮的点击事件
  },

  onChooseAvatar(e) {
    console.log(123)
    const {
      avatarUrl
    } = e.detail
    this.setData({
      avatarUrl,
    })
  },

  onSend: function () {
    const that = this;
    const inputValue = this.data.inputValue.trim();
    const inputValue1 = this.data.inputValue.trim();
    var loclData = this.data;
    if (inputValue.length > 0) {
      that.setData({
        loading: true
      }); // 显示等待动效
      that.addMessage(inputValue, 'right', '/static/images/my.png');
      const messages = this.data.messages;
      const myOptions = this.data.myOptions;
      console.log(myOptions)
      this.setData({
        toView: `item${messages.length}`,
        inputValue: '',
      });

      const task = wx.request({
        url: 'https://chat.2guliang.top/chat-process', // 替换为真实的 API 地址
        method: 'POST',
        data: {
          prompt: inputValue1,
          options: myOptions,
          secretkeystr: ""
        },
        header: {
          'content-type': 'application/json',
          'authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDM0MTljYTc0OTYyMDFlZTVmMzY1MTAiLCJpZCI6Ijk3OWQ2N2Q3LTliNWUtNDIwYi05MzQ3LThjZmE5MzQxNDFlNSIsImludml0ZVBvaW50cyI6MCwiYm9udXNQb2ludHMiOjIwMDAwLCJ1c2VkRGFpbHlQb2ludHMiOjAsImNoYXJnZVBvaW50cyI6MCwib3BlbmlkIjoib2RuaEw1ZzhZUlZibEJiVjB5S0REenFsTUo1byIsImludml0ZUNvZGUiOiI5YzQwMGE5MyIsImNyZWF0ZVRpbWUiOiI0LzEwLzIwMjMsIDEwOjE0OjM0IFBNIiwiaWF0IjoxNjgxMTM2MDc0fQ.jQvJM-iPV9zBR11u1C618wfXdhX952qXD2UpKg33c6A'
        },
        responseType: 'arraybuffer',
        timeout: 30000,
        enableChunked: true,
        success(res) {
          that.setData({ loading: false });
          // const lines = res.data.split('\n'); // 将字符串按照换行符分割成多行
          // const lastLine = lines[lines.length - 1]; // 取得最后一行
          // const jsonData = JSON.parse(lastLine);
          // console.log(jsonData.id)
          // that.setData({myOptions : {"parentMessageId":""+jsonData.id}})
          // that.addMessage(jsonData.text, 'left', '/static/images/avatar.png');
          // that.setData({ loading: false });
          // that.setData({
          //   toView: `item${messages.length}`,
          // });
        },
        fail(res) {
          that.addMessage("接口错误了哦，联系管理员", 'left', '/static/images/avatar.png');
          that.setData({
            loading: false
          });
          console.log('Error: ', res);
          that.setData({
            toView: `item${messages.length}`,
          });
        }
      });
      var num = 0
      var first = true;
      task.onChunkReceived(function (response) {
        num++;
        if (num > 2) {
          const arrayBuffer = response.data;
          const data16 = buf2hex(arrayBuffer) // ArrayBuffer转16进制
          const ret = hexToStr(data16) // 16进制转字符串
          let mut = ret.slice();
          mut = mut.replace('\n','');
          console.log('--'+ret)
          try {
            const jsonData = JSON.parse(mut);
            if(first) {
              first =false;
              that.setData({myOptions : {"parentMessageId":""+jsonData.id}})
              that.addMessage(jsonData.text, 'left', '/static/images/avatar.png');
            } else {
              if (jsonData.text.length > 0) {
                console.log(123)
                that.addMessage(jsonData.text, 'left', '/static/images/avatar.png', true);
              }
              
            }
            that.setData({
              toView: `item${messages.length}`,
            });
            
          } catch (e) {
            
          }
          

        }
       

      });
      // task.onChunkReceived(function(response) {
      //   const arrayBuffer = response.data;
      //   const uint8Array = new Uint8Array(arrayBuffer);
      //   let text = String.fromCharCode.apply(null, uint8Array);
      //   buffer += text;
      //   full_command.value = buffer
      // })

      // // task.onChunkReceived(function (response) {
      //   const arrayBuffer = response.data;
      //   const uint8Array = new Uint8Array(arrayBuffer);
      //   let text = String.fromCharCode.apply(null, uint8Array);
      //   buffer += text;
      //   full_command.value = buffer
      // // })


    }
  },

  onTap(buf) {
    let randomNum = Math.floor(Math.random() * 255) + 1;
    let ca = this.data.color_arr
    this.setData({
      color:ca[randomNum]
    })
  },
  onMessageLongTap: function (event) {
    let copy = '';
    
    this.data.str_messages.forEach(element => {
      copy = copy.concat(element.content)+'\n'
    });
    wx.setClipboardData({
      data: copy,
      success: function (res) {
        console.log(222)
        wx.showToast({
          title: '已复制所有消息',
          duration: 1000
        });
      },fail: function (params) {
        console.log(123)
        console.log(params)
      }
    });
    console.log('sss')
  }


});

